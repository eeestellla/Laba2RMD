package com.example.laba2

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.laba2.ui.theme.Laba2Theme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Laba2Theme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFFF3E5F5) // фон вікна
                ) {
                    UserFormScreen()
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UserFormScreen() {
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "Ласкаво просимо!",
            fontSize = 28.sp,
            color = Color(0xFF4A148C),
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Serif,
            modifier = Modifier.padding(bottom = 24.dp)
        )

        OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            label = { Text("Введіть ім’я") },
            colors = TextFieldDefaults.colors(
                focusedIndicatorColor = Color(0xFF6A1B9A),
                unfocusedIndicatorColor = Color(0xFFBA68C8),
                focusedContainerColor = Color(0xFFF8EAF6),
                unfocusedContainerColor = Color(0xFFF8EAF6)
            ),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp)
        )

        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("Введіть email") },
            colors = TextFieldDefaults.colors(
                focusedIndicatorColor = Color(0xFF6A1B9A),
                unfocusedIndicatorColor = Color(0xFFBA68C8),
                focusedContainerColor = Color(0xFFF8EAF6),
                unfocusedContainerColor = Color(0xFFF8EAF6)
            ),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 24.dp)
        )

        Button(
            onClick = { /* TODO: натискання */ },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6A1B9A)),
            shape = MaterialTheme.shapes.medium
        ) {
            Text(
                text = "Надіслати",
                fontSize = 18.sp,
                fontFamily = FontFamily.Serif,
                color = Color.White
            )
        }
    }
}